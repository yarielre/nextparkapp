﻿namespace Inside.Domain.Enum
{
    public enum OrderStatus
    {
        Actived,
        Finished
    }
}