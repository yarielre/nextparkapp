﻿namespace Inside.Domain.Enums
{
    public enum MyDayOfWeek
    {
        Sunday,
        Monday,
        Tuesday,
        Wednesday,
        Thursday,
        Friday,
        Saturday
    }
}