﻿namespace Inside.Domain.Enum
{
    public enum ObjectState
    {
        Added,
        Unchanged,
        Modified,
        PartiallyModified,
        Deleted
    }
}