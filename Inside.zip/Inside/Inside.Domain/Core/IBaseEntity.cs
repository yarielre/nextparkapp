﻿namespace Inside.Domain.Core
{
    public interface IBaseEntity
    {
        int Id { get; set; }
    }
}