﻿namespace Inside.Domain.Core
{
    public class BaseEntity:IBaseEntity
    {
        public int Id { get; set; }
    }
}