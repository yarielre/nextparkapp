﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Inside.Domain.Models
{
   public class RenovateOrder
    {
        public OrderModel Order { get; set; }
        public UserModel User { get; set; }
    }
}
