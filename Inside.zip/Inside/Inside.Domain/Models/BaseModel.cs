﻿namespace Inside.Domain.Models
{
    public class BaseModel
    {
        public int Id { get; set; }
    }
}
