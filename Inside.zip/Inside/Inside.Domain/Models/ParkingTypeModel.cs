﻿using System.Collections.Generic;
using Inside.Domain.Entities;

namespace Inside.Domain.Models
{
    public class ParkingTypeModel:BaseModel
    {
        public string Type { get; set; }

    }
}
