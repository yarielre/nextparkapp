﻿namespace NextPark.Enums
{
    public enum MyMonthOfYear
    {
        Nothing,
        January,
        February,
        March,
        April,
        May,
        June,
        July,
       August,
       September,
       October,
       November,
       December
    }
}
