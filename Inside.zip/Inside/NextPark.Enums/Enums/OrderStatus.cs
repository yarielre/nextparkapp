﻿namespace NextPark.Enums
{
    public enum OrderStatus
    {
        Actived,
        Finished
    }
}