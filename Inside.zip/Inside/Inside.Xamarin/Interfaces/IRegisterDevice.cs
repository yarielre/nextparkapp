﻿//using System;
//using System.Collections.Generic;
//using System.Text;

//namespace Inside.Xamarin.Interfaces
//{
//   public interface IRegisterDevice
//    {
//        void RegisterDevice();
//    }
//}
