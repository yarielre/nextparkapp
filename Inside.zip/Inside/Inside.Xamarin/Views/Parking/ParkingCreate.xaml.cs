﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Maps;
using Xamarin.Forms.Xaml;

namespace Inside.Xamarin.Views.Parking
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class ParkingCreate : ContentPage
	{
	    public ParkingCreate ()
		{
			InitializeComponent ();
		}
    }
}