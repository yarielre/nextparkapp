﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace Inside.Xamarin.Views.Rents
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class RentsByHoursPage : ContentPage
    {
        public RentsByHoursPage()
        {
            InitializeComponent();
        }
    }
}