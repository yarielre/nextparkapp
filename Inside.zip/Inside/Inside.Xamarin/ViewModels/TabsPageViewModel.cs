﻿namespace Inside.Xamarin.ViewModels
{
    public class TabsPageViewModel : BaseViewModel
    {
        public TabsPageViewModel() {
        }
    }
}
