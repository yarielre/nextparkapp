﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Foundation;
using UIKit;

namespace Inside.Xamarin.iOS.Constants
{
    public class Constants
    {
        public static string ListenConnectionString = "Endpoint=sb://insideparking.servicebus.windows.net/;SharedAccessKeyName=DefaultListenSharedAccessSignature;SharedAccessKey=CCdEnxEEL+HDY+AARr3wfBnslLwLdBwBHTAEjaKpgRk=";
        public static string NotificationHubName = "InsideParkingHub";
    }
}