﻿using System;
namespace NextPark.Mobile.ViewModels
{
    public class StartUpViewModel
    {
        public StartUpViewModel()
        {
        }
    }
}
