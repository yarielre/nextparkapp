﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace NextPark.Mobile.Views
{
    public partial class StartUp : ContentPage
    {
        public StartUp()
        {
            InitializeComponent();
        }

        //protected override void OnAppearing()
        //{
        //    (this.BindingContext as BaseViewModel).NavService.InitializeAsync();
        //}
    }
}
