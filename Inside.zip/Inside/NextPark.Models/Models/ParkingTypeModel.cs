﻿namespace NextPark.Models
{
    public class ParkingTypeModel:BaseModel
    {
        public string Type { get; set; }

    }
}
