﻿namespace NextPark.Models
{
    public class RenovateOrder
    {
        public OrderModel Order { get; set; }
        public UserModel User { get; set; }
    }
}
