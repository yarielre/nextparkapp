﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NextPark.Models
{
  public  class UpdateUserCoinModel
    {
        public int UserId { get; set; }
        public double Coins { get; set; }
    }
}
