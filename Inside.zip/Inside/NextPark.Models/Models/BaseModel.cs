﻿namespace NextPark.Models
{
    public class BaseModel
    {
        public int Id { get; set; }
    }
}
