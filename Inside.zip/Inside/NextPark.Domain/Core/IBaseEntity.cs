﻿namespace NextPark.Domain.Core
{
    public interface IBaseEntity
    {
        int Id { get; set; }
    }
}