﻿using Microsoft.AspNetCore.Identity;

namespace NextPark.Domain.Auth
{
    public class UserToken:IdentityUserToken<int>
    {
    }
}
