﻿using Microsoft.AspNetCore.Identity;

namespace NextPark.Domain.Auth
{
    public class UserClaim:IdentityUserClaim<int>
    {
    }
}
