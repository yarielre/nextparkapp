﻿using Microsoft.AspNetCore.Identity;

namespace NextPark.Domain.Auth
{
    public class UserLogin:IdentityUserLogin<int>
    {
    }
}
