﻿using Microsoft.AspNetCore.Identity;

namespace NextPark.Domain.Entities
{
    public class ApplicationRole : IdentityRole<int>
    {
    }
}
