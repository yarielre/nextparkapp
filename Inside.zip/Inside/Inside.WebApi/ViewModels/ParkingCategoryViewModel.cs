﻿namespace Inside.WebApi.ViewModels
{
    public class ParkingCategoryViewModel : BaseViewModel
    {
        public string Category { get; set; }
        public double Price { get; set; }
        public double CoinPrice { get; set; }

    }
}