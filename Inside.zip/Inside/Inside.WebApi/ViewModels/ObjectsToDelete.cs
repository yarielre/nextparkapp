﻿using System.Collections.Generic;

namespace Inside.WebApi.ViewModels
{
    public class ObjectsToDelete
    {
        public List<int> Ids { get; set; }
    }
}