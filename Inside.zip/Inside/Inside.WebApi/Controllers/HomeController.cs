﻿using Microsoft.AspNetCore.Mvc;

namespace Inside.WebApi.Controllers
{
    [Route("api/[controller]")]
    public class HomeController : Controller
    {
        // GET
        //public IActionResult Index()
        //{
        //    return View();
        //}
    }
}